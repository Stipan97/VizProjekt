Kako bi uspješno mogli pokrenuti index.html potrebno je pokrenuti lokalni server.
Način na koji sam osobno pokretao aplikaciju je preko Visual Studio Code-a.
Potrebno je skinuti ekstenziju Live Server i otići na "Go Live" opciju, te će
se aplikacija automatski pokrenuti u nekom od internetskih preglednika i moći
ćete koristiti aplikaciju u potpunosti.